from django.apps import AppConfig


class TestConfig(AppConfig):
    name = 'Test'
